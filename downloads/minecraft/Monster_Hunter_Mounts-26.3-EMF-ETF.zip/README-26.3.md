# Monster Hunter Mounts — Java 26.3 / EMF + ETF

原作者：FluffyYutyrannus。保留原包贴图、造型、音效和作者署名。

## 安装

将 `Monster_Hunter_Mounts-26.3-EMF-ETF.zip` 放入当前游戏实例的
`resourcepacks` 目录，在游戏内启用。解压后的本文件所在目录也可直接作为资源包使用。
使用适配 **Java 26.3** 的 EMF 与 ETF，并将本包放在其他修改马类模型的资源包上方。
本次读取到本地实例安装的是 EMF 3.3.8、ETF 7.2.4。

本版本专用于 26.3，资源格式为 `[97, 1]`。它不是原版客户端可独立加载的生物模型包，
也不声明兼容 OptiFine 或旧版 Minecraft。

## 修复内容

- 将马、驴、骡、骷髅马和僵尸马的鞍、缰绳、头带拆到各自的 `_saddle.jem`。
  装备层使用新的 `textures/entity/equipment/*_saddle/saddle.png` 路径。
- 清空鞍装备层中的身体几何体，避免叠加第二层身体；主体和马铠移除已经失效的旧鞍部件。
- 为五种生物提供独立幼年模型。保留原包幼年鸟形造型；幼年驴、骡采用原有造型的半尺寸版本。
  原版骨架只提供动作，独立自定义骨架承接旋转与位置变化，以适应 26.1 后幼年驴的骨架层级变化。
  原有嘴部、鬃毛几何体保留在自定义颈部层级内，不再引用已经移除的原版部件。
- 补齐客户端实际存在的全部 15 个马类 `_baby.png` 路径，包括透明花纹层。
- 保留普通马七种配色、`Sven` 命名贴图及对应的鞍配色；鞍通过 ETF 的装备贴图规则匹配。
- 补充亡灵马铠模型以及新版铜、下界合金马铠贴图路径。**铜马铠沿用金色外观，
  下界合金马铠沿用铁色外观**；没有新绘制这两种材质。透明皮革外层避免混入原版 UV。

## 验证范围

已对照 Mojang 26.3 客户端（SHA-1 `e877b6a07acd633fb3bb475002175cec036e7b87`）
中的模型字节码和资源路径，以及 EMF 官方部件映射进行迁移。
静态验证包括：模型部件名称、动画目标、唯一模型 ID、拆分前后的几何体数量、幼年模型基准缩放、
贴图路径、PNG 文件头、JSON 语法与 14 个鞍配色规则。

**尚未在运行中的 Minecraft 内验证渲染效果。** 静态检查不能代替实机检查，尤其是骑乘、
进食、站立、幼年动作及多个材质包叠加的效果。

建议在创造模式依次确认：

1. 五种成年生物空身、装鞍、骑乘时的鞍和缰绳是否贴合；驴、骡装箱子是否正常。
2. 普通马七种毛色与命名 `Sven` 后的配色，包含重新加载资源包后的效果。
3. 五种幼年生物的嘴部、身体连接、脚部位置，以及走动、进食和站立动作。
4. 普通马和支持装备的亡灵马的各种马铠、皮革染色与附魔效果。

可用 `/summon minecraft:horse ~ ~ ~ {Age:-24000}` 生成幼年马；
将 `horse` 替换为 `donkey`、`mule`、`skeleton_horse`、`zombie_horse` 检查其他幼年模型。
给成年个体装鞍和马铠时，直接使用游戏界面即可。

## 修改依据

- [Minecraft Java 26.3 发布说明](https://www.minecraft.net/en-us/article/minecraft-java-edition-26-3)
- [Minecraft Java 1.21.5 装备层变更](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-5)
- [EMF 官方部件映射](https://github.com/Traben-0/Entity_Model_Features/blob/master/src/main/java/traben/entity_model_features/models/EMFModelMappings.java)
- [EMF 更新记录](https://github.com/Traben-0/Entity_Model_Features/blob/master/CHANGELOG.MD)

工作目录中的 `.work/Monster_Hunter_Mounts-original.zip` 是修改前的备份；
`.work/migrate.ps1` 和 `.work/validate.ps1` 分别记录迁移与验证步骤。
这些开发文件与官方客户端不包含在交付 ZIP 中。
